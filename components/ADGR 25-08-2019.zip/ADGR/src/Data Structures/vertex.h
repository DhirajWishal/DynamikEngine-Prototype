#pragma once

#include "adgrafx.h"

namespace Dynamik {
	namespace ADGR {


	}
}


