#pragma once

#include <vector>

namespace Dynamik {
	namespace ADGR {
		namespace core {

			typedef std::vector<char> DMK_ShaderCode;
		}
	}
}
