#include "adgrafx.h"
//
//#include "src/Renderer.h"
//
//int main() {
//	Dynamik::ADGR::Renderer myRenderer;
//
//	try {
//		myRenderer.initRenderer();
//		while (true)	// TODO:: poll events
//			myRenderer.run();
//		myRenderer.end();
//	}
//	catch (std::exception& e) {
//		printf(e.what());
//	}
//
//	return 0;
//}
//
// topping off at 3,696 code lines (03/08/2019)
