#pragma once

namespace Dynamik {
	namespace ADGR {

	}
}
