#include "adgrafx.h"
#include "layer.h"

namespace Dynamik {
	namespace ADGR {

		Layer::Layer(const std::string& name) : debugName(name) {
		}

		Layer::~Layer() {
		}
	}
}