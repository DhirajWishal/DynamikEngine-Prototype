#include "adgrafx.h"
#include "dll_wrapper.h"

namespace Dynamik {
	namespace ADGR {

	}
}
