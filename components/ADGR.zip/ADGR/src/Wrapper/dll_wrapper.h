#pragma once

#define WRAPPER_EXPORT extern "C" __declspec(dllexport)

namespace Dynamik {
	namespace ADGR {

	}
}
