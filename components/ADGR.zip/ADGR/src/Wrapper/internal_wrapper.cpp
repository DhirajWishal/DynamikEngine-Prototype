#include "adgrafx.h"
#include "internal_wrapper.h"

namespace Dynamik {
	namespace ADGR {

	}
}
