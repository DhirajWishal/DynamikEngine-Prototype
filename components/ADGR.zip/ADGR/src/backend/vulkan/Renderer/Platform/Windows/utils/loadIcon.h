#pragma once

namespace Dynamik {
	namespace ADGR {
		std::fstream load_icon(std::string path);
	}
}
