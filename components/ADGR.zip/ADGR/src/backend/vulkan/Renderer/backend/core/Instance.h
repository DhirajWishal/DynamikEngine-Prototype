#pragma once

#include "Core.h"

namespace Dynamik {
	namespace ADGR {
		namespace core {

			class Instance : public Core {
			public:
				Instance() {}
				virtual ~Instance() {}

			};
		}
	}
}