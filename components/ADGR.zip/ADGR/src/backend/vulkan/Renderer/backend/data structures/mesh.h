#pragma once


namespace Dynamik {
	namespace ADGR {
		namespace core {

			struct MeshData {

			};
		}
	}
}